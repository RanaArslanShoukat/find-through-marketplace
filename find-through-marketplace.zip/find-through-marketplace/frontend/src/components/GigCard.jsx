import { Link } from 'react-router-dom';

const GigCard = ({ gig }) => (
  <Link
    to={`/gigs/${gig._id}`}
    className="block bg-white border border-gray-200 rounded-lg p-5 hover:shadow-md hover:border-brand-300 transition"
  >
    <div className="flex justify-between items-start">
      <h3 className="font-semibold text-gray-900">{gig.title}</h3>
      <span className="text-brand-600 font-medium whitespace-nowrap ml-4">
        ${gig.budgetMin}–${gig.budgetMax}
        {gig.budgetType === 'hourly' ? '/hr' : ''}
      </span>
    </div>
    <p className="text-gray-500 text-sm mt-1 line-clamp-2">{gig.description}</p>
    <div className="flex flex-wrap gap-1.5 mt-3">
      {gig.skillsRequired?.slice(0, 5).map((skill) => (
        <span key={skill} className="text-xs bg-brand-50 text-brand-700 px-2 py-0.5 rounded-full">
          {skill}
        </span>
      ))}
    </div>
    <div className="flex justify-between items-center mt-3 text-xs text-gray-400">
      <span>{gig.employer?.name || gig.employer?.companyName}</span>
      <span>{gig.location} · {gig.applicantsCount} applicants</span>
    </div>
  </Link>
);

export default GigCard;
