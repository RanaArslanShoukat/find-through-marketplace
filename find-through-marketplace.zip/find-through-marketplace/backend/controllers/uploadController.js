const asyncHandler = require('express-async-handler');

// This stores files to local disk (/uploads) via multer — see routes/uploadRoutes.js.
// To swap in Cloudinary or S3 for production: replace multer's diskStorage with
// multer-storage-cloudinary or a multer-s3 storage engine, keep this same
// controller shape, and just return the cloud URL instead of the local path.
const uploadFile = asyncHandler(async (req, res) => {
  if (!req.file) {
    res.status(400);
    throw new Error('No file uploaded');
  }

  const fileUrl = `/uploads/${req.file.filename}`;
  res.status(201).json({ url: fileUrl, originalName: req.file.originalname });
});

module.exports = { uploadFile };
