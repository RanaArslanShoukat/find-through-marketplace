const asyncHandler = require('express-async-handler');
const mongoose = require('mongoose');
const Gig = require('../models/Gig');

// @route POST /api/gigs   (employer only)
const createGig = asyncHandler(async (req, res) => {
  const { title, description, skillsRequired, budgetType, budgetMin, budgetMax, location } = req.body;

  const gig = await Gig.create({
    employer: req.user._id,
    title,
    description,
    skillsRequired,
    budgetType,
    budgetMin,
    budgetMax,
    location,
  });

  res.status(201).json(gig);
});

// @route GET /api/gigs
// Supports: ?keyword=&skills=react,node&minBudget=&maxBudget=&location=&page=&limit=&sort=
// Uses an aggregation pipeline so filtering + sorting + pagination happen in one DB round trip.
const getGigs = asyncHandler(async (req, res) => {
  const {
    keyword,
    skills,
    minBudget,
    maxBudget,
    location,
    status = 'open',
    page = 1,
    limit = 10,
    sort = '-createdAt',
  } = req.query;

  const pipeline = [];
  const match = {};

  if (status) match.status = status;
  if (location) match.location = { $regex: location, $options: 'i' };
  if (skills) {
    const skillsArr = skills.split(',').map((s) => s.trim());
    match.skillsRequired = { $in: skillsArr };
  }
  if (minBudget || maxBudget) {
    match.budgetMax = {};
    if (minBudget) match.budgetMax.$gte = Number(minBudget);
    if (maxBudget) match.budgetMin = { $lte: Number(maxBudget) };
  }
  if (keyword) {
    match.$text = { $search: keyword };
  }

  pipeline.push({ $match: match });

  // Join employer info (like a SQL join) instead of a second round trip
  pipeline.push({
    $lookup: {
      from: 'users',
      localField: 'employer',
      foreignField: '_id',
      as: 'employer',
      pipeline: [{ $project: { name: 1, companyName: 1, avatarUrl: 1 } }],
    },
  });
  pipeline.push({ $unwind: '$employer' });

  const sortField = sort.startsWith('-') ? sort.slice(1) : sort;
  const sortDir = sort.startsWith('-') ? -1 : 1;
  pipeline.push({ $sort: { [sortField]: sortDir } });

  // $facet lets us get paginated results AND a total count in a single aggregation call
  pipeline.push({
    $facet: {
      data: [{ $skip: (Number(page) - 1) * Number(limit) }, { $limit: Number(limit) }],
      totalCount: [{ $count: 'count' }],
    },
  });

  const result = await Gig.aggregate(pipeline);
  const gigs = result[0].data;
  const total = result[0].totalCount[0]?.count || 0;

  res.json({
    gigs,
    page: Number(page),
    totalPages: Math.ceil(total / Number(limit)),
    totalResults: total,
  });
});

// @route GET /api/gigs/:id
const getGigById = asyncHandler(async (req, res) => {
  const gig = await Gig.findById(req.params.id)
    .populate('employer', 'name companyName avatarUrl')
    .populate('hiredFreelancer', 'name avatarUrl');

  if (!gig) {
    res.status(404);
    throw new Error('Gig not found');
  }
  res.json(gig);
});

// @route PUT /api/gigs/:id   (owning employer only)
const updateGig = asyncHandler(async (req, res) => {
  const gig = await Gig.findById(req.params.id);
  if (!gig) {
    res.status(404);
    throw new Error('Gig not found');
  }
  if (gig.employer.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to edit this gig');
  }

  Object.assign(gig, req.body);
  await gig.save();
  res.json(gig);
});

// @route DELETE /api/gigs/:id   (owning employer only)
const deleteGig = asyncHandler(async (req, res) => {
  const gig = await Gig.findById(req.params.id);
  if (!gig) {
    res.status(404);
    throw new Error('Gig not found');
  }
  if (gig.employer.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to delete this gig');
  }
  await gig.deleteOne();
  res.json({ message: 'Gig removed' });
});

// @route GET /api/gigs/mine   (employer's own posted gigs)
const getMyGigs = asyncHandler(async (req, res) => {
  const gigs = await Gig.find({ employer: req.user._id }).sort('-createdAt');
  res.json(gigs);
});

module.exports = { createGig, getGigs, getGigById, updateGig, deleteGig, getMyGigs };
