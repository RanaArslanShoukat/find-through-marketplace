const express = require('express');
const router = express.Router();
const {
  startOrGetConversation,
  getMyConversations,
  getMessages,
} = require('../controllers/messageController');
const { protect } = require('../middleware/auth');

router.post('/', protect, startOrGetConversation);
router.get('/', protect, getMyConversations);
router.get('/:id/messages', protect, getMessages);

module.exports = router;
