const mongoose = require('mongoose');

const gigSchema = new mongoose.Schema(
  {
    employer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true },
    skillsRequired: [{ type: String, index: true }],
    budgetType: { type: String, enum: ['fixed', 'hourly'], default: 'fixed' },
    budgetMin: { type: Number, required: true },
    budgetMax: { type: Number, required: true },
    location: { type: String, default: 'Remote' },
    status: { type: String, enum: ['open', 'in_progress', 'completed', 'closed'], default: 'open' },
    paymentStatus: { type: String, enum: ['unpaid', 'escrow', 'released', 'refunded'], default: 'unpaid' },
    hiredFreelancer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    applicantsCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

gigSchema.index({ title: 'text', description: 'text' });

module.exports = mongoose.model('Gig', gigSchema);
