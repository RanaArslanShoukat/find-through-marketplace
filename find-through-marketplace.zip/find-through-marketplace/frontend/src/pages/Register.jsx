import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Register = () => {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'freelancer', companyName: '' });
  const [error, setError] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await register(form);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <div className="max-w-sm mx-auto mt-12 bg-white p-8 rounded-lg border border-gray-200">
      <h1 className="text-xl font-bold mb-6">Create your account</h1>
      {error && <p className="text-red-600 text-sm mb-4">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex gap-2">
          <button type="button"
            onClick={() => setForm({ ...form, role: 'freelancer' })}
            className={`flex-1 py-2 rounded-md border text-sm ${form.role === 'freelancer' ? 'bg-brand-600 text-white border-brand-600' : 'border-gray-300'}`}>
            I'm a Freelancer
          </button>
          <button type="button"
            onClick={() => setForm({ ...form, role: 'employer' })}
            className={`flex-1 py-2 rounded-md border text-sm ${form.role === 'employer' ? 'bg-brand-600 text-white border-brand-600' : 'border-gray-300'}`}>
            I'm an Employer
          </button>
        </div>
        <input name="name" placeholder="Full name" value={form.name} required onChange={handleChange}
          className="w-full border border-gray-300 rounded-md px-3 py-2" />
        <input name="email" type="email" placeholder="Email" value={form.email} required onChange={handleChange}
          className="w-full border border-gray-300 rounded-md px-3 py-2" />
        <input name="password" type="password" placeholder="Password (min 6 chars)" value={form.password} required minLength={6}
          onChange={handleChange} className="w-full border border-gray-300 rounded-md px-3 py-2" />
        {form.role === 'employer' && (
          <input name="companyName" placeholder="Company name" value={form.companyName} onChange={handleChange}
            className="w-full border border-gray-300 rounded-md px-3 py-2" />
        )}
        <button className="w-full bg-brand-600 text-white py-2 rounded-md hover:bg-brand-700">
          Create account
        </button>
      </form>
      <p className="text-sm text-gray-500 mt-4">
        Already have an account? <Link to="/login" className="text-brand-600">Log in</Link>
      </p>
    </div>
  );
};

export default Register;
