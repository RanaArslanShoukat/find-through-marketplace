import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

const GigDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [gig, setGig] = useState(null);
  const [applying, setApplying] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [proposedRate, setProposedRate] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    api.get(`/gigs/${id}`).then((res) => setGig(res.data));
  }, [id]);

  const handleApply = async (e) => {
    e.preventDefault();
    try {
      await api.post('/applications', { gigId: id, coverLetter, proposedRate: Number(proposedRate) });
      setMessage('Application submitted!');
      setApplying(false);
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to apply');
    }
  };

  const handleMessageEmployer = async () => {
    const { data } = await api.post('/conversations', { recipientId: gig.employer._id, gigId: gig._id });
    navigate('/chat', { state: { conversationId: data._id } });
  };

  if (!gig) return <p className="p-8 text-center text-gray-500">Loading...</p>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex justify-between items-start">
          <h1 className="text-2xl font-bold">{gig.title}</h1>
          <span className="text-brand-600 font-semibold text-lg">
            ${gig.budgetMin}–${gig.budgetMax}{gig.budgetType === 'hourly' ? '/hr' : ''}
          </span>
        </div>
        <p className="text-gray-500 text-sm mt-1">
          Posted by {gig.employer?.name} {gig.employer?.companyName && `· ${gig.employer.companyName}`} · {gig.location}
        </p>

        <div className="flex flex-wrap gap-1.5 mt-4">
          {gig.skillsRequired?.map((s) => (
            <span key={s} className="text-xs bg-brand-50 text-brand-700 px-2 py-0.5 rounded-full">{s}</span>
          ))}
        </div>

        <p className="mt-4 text-gray-700 whitespace-pre-line">{gig.description}</p>

        {message && <p className="mt-4 text-sm text-green-600">{message}</p>}

        {user?.role === 'freelancer' && gig.status === 'open' && (
          <div className="mt-6">
            {!applying ? (
              <div className="flex gap-3">
                <button onClick={() => setApplying(true)} className="bg-brand-600 text-white px-4 py-2 rounded-md text-sm">
                  Apply Now
                </button>
                <button onClick={handleMessageEmployer} className="border border-gray-300 px-4 py-2 rounded-md text-sm">
                  Message Employer
                </button>
              </div>
            ) : (
              <form onSubmit={handleApply} className="space-y-3 mt-2">
                <textarea required placeholder="Cover letter" value={coverLetter}
                  onChange={(e) => setCoverLetter(e.target.value)} rows={4}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" />
                <input required type="number" placeholder="Your proposed rate ($)" value={proposedRate}
                  onChange={(e) => setProposedRate(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" />
                <button className="bg-brand-600 text-white px-4 py-2 rounded-md text-sm">Submit Application</button>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default GigDetail;
