const jwt = require('jsonwebtoken');

// Access token: short-lived, sent on every request via Authorization header
const generateAccessToken = (userId, role) => {
  return jwt.sign({ id: userId, role }, process.env.JWT_ACCESS_SECRET, {
    expiresIn: process.env.ACCESS_TOKEN_EXPIRES || '15m',
  });
};

// Refresh token: long-lived, stored in an httpOnly cookie + hashed list on the user doc
const generateRefreshToken = (userId) => {
  return jwt.sign({ id: userId }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.REFRESH_TOKEN_EXPIRES || '7d',
  });
};

module.exports = { generateAccessToken, generateRefreshToken };
