const asyncHandler = require('express-async-handler');
const Application = require('../models/Application');
const Gig = require('../models/Gig');

// @route POST /api/applications   (freelancer only)
const applyToGig = asyncHandler(async (req, res) => {
  const { gigId, coverLetter, proposedRate } = req.body;

  const gig = await Gig.findById(gigId);
  if (!gig || gig.status !== 'open') {
    res.status(400);
    throw new Error('This gig is not accepting applications');
  }

  const existing = await Application.findOne({ gig: gigId, freelancer: req.user._id });
  if (existing) {
    res.status(400);
    throw new Error('You have already applied to this gig');
  }

  const application = await Application.create({
    gig: gigId,
    freelancer: req.user._id,
    coverLetter,
    proposedRate,
    resumeUrl: req.user.resumeUrl,
  });

  gig.applicantsCount += 1;
  await gig.save();

  res.status(201).json(application);
});

// @route GET /api/applications/gig/:gigId   (employer views applicants for their gig)
const getApplicationsForGig = asyncHandler(async (req, res) => {
  const gig = await Gig.findById(req.params.gigId);
  if (!gig) {
    res.status(404);
    throw new Error('Gig not found');
  }
  if (gig.employer.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to view these applications');
  }

  const applications = await Application.find({ gig: req.params.gigId })
    .populate('freelancer', 'name skills bio hourlyRate avatarUrl portfolioUrl')
    .sort('-createdAt');

  res.json(applications);
});

// @route GET /api/applications/mine   (freelancer views their own applications)
const getMyApplications = asyncHandler(async (req, res) => {
  const applications = await Application.find({ freelancer: req.user._id })
    .populate('gig', 'title budgetMin budgetMax status employer')
    .sort('-createdAt');
  res.json(applications);
});

// @route PUT /api/applications/:id/status   (employer accepts/rejects)
const updateApplicationStatus = asyncHandler(async (req, res) => {
  const { status } = req.body; // 'accepted' | 'rejected'

  const application = await Application.findById(req.params.id).populate('gig');
  if (!application) {
    res.status(404);
    throw new Error('Application not found');
  }
  if (application.gig.employer.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized');
  }

  application.status = status;
  await application.save();

  // If accepted, lock in the freelancer and move the gig to in_progress
  if (status === 'accepted') {
    await Gig.findByIdAndUpdate(application.gig._id, {
      hiredFreelancer: application.freelancer,
      status: 'in_progress',
    });
  }

  res.json(application);
});

module.exports = { applyToGig, getApplicationsForGig, getMyApplications, updateApplicationStatus };
