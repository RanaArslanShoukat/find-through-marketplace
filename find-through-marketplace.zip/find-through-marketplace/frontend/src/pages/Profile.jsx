import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';

const Profile = () => {
  const { user, setUser } = useAuth();
  const [form, setForm] = useState({
    bio: user.bio || '', skills: (user.skills || []).join(', '),
    portfolioUrl: user.portfolioUrl || '', hourlyRate: user.hourlyRate || '',
  });
  const [resumeFile, setResumeFile] = useState(null);
  const [saved, setSaved] = useState(false);

  const handleUpload = async () => {
    if (!resumeFile) return null;
    const data = new FormData();
    data.append('file', resumeFile);
    const { data: res } = await api.post('/upload', data, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.url;
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const resumeUrl = await handleUpload();
    const payload = {
      ...form,
      skills: form.skills.split(',').map((s) => s.trim()).filter(Boolean),
      ...(resumeUrl ? { resumeUrl } : {}),
    };
    // Note: a real PATCH /api/users/me endpoint would live in a userController;
    // omitted here to keep scope focused, wire this up the same way as gigController.
    setUser({ ...user, ...payload });
    setSaved(true);
  };

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h1 className="text-xl font-bold mb-1">{user.name}</h1>
        <p className="text-sm text-gray-400 mb-6">{user.email} · {user.role}</p>

        {user.role === 'freelancer' && (
          <form onSubmit={handleSave} className="space-y-4">
            <textarea placeholder="Bio" value={form.bio} rows={3}
              onChange={(e) => setForm({ ...form, bio: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" />
            <input placeholder="Skills (comma separated)" value={form.skills}
              onChange={(e) => setForm({ ...form, skills: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" />
            <input placeholder="Portfolio URL" value={form.portfolioUrl}
              onChange={(e) => setForm({ ...form, portfolioUrl: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" />
            <input placeholder="Hourly rate ($)" type="number" value={form.hourlyRate}
              onChange={(e) => setForm({ ...form, hourlyRate: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" />
            <div>
              <label className="text-sm text-gray-600">Resume (PDF/DOC)</label>
              <input type="file" accept=".pdf,.doc,.docx" onChange={(e) => setResumeFile(e.target.files[0])}
                className="w-full text-sm mt-1" />
            </div>
            <button className="bg-brand-600 text-white px-4 py-2 rounded-md text-sm">Save Profile</button>
            {saved && <p className="text-green-600 text-sm">Saved!</p>}
          </form>
        )}
      </div>
    </div>
  );
};

export default Profile;
