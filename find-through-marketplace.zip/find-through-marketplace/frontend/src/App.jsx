import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './pages/Login';
import Register from './pages/Register';
import GigList from './pages/GigList';
import GigDetail from './pages/GigDetail';
import PostGig from './pages/PostGig';
import Dashboard from './pages/Dashboard';
import Chat from './pages/Chat';
import Profile from './pages/Profile';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-brand-50/60 via-white to-white">
      <Navbar />
      <Routes>
        <Route path="/" element={<GigList />} />
        <Route path="/gigs" element={<GigList />} />
        <Route path="/gigs/:id" element={<GigDetail />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/post-gig"
          element={<ProtectedRoute roles={['employer']}><PostGig /></ProtectedRoute>}
        />
        <Route
          path="/dashboard"
          element={<ProtectedRoute><Dashboard /></ProtectedRoute>}
        />
        <Route
          path="/chat"
          element={<ProtectedRoute><Chat /></ProtectedRoute>}
        />
        <Route
          path="/profile"
          element={<ProtectedRoute><Profile /></ProtectedRoute>}
        />
      </Routes>
    </div>
  );
}

export default App;
