const jwt = require('jsonwebtoken');
const { saveMessage } = require('../controllers/messageController');

// Maps userId -> socketId so we can push messages to a specific online user
const onlineUsers = new Map();

const initSocket = (io) => {
  // Auth middleware for socket connections: client sends the access token
  // as `socket.handshake.auth.token`
  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('No token provided'));
      const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET);
      socket.userId = decoded.id;
      next();
    } catch (err) {
      next(new Error('Authentication failed'));
    }
  });

  io.on('connection', (socket) => {
    onlineUsers.set(socket.userId, socket.id);
    console.log(`User connected: ${socket.userId}`);

    socket.on('joinConversation', (conversationId) => {
      socket.join(conversationId);
    });

    socket.on('sendMessage', async ({ conversationId, text }) => {
      try {
        const message = await saveMessage({ conversationId, senderId: socket.userId, text });
        io.to(conversationId).emit('newMessage', message);
      } catch (err) {
        socket.emit('errorMessage', { message: 'Failed to send message' });
      }
    });

    socket.on('typing', ({ conversationId }) => {
      socket.to(conversationId).emit('userTyping', { userId: socket.userId });
    });

    socket.on('disconnect', () => {
      onlineUsers.delete(socket.userId);
      console.log(`User disconnected: ${socket.userId}`);
    });
  });
};

module.exports = { initSocket };
