import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-10">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-teal-700 flex items-center justify-center text-white font-bold text-sm shadow-sm">
            FT
          </span>
          <span className="font-bold text-ink-900 text-lg tracking-tight">Find Through</span>
        </Link>
        <div className="flex items-center gap-5 text-sm">
          <Link to="/gigs" className="text-ink-700 hover:text-brand-600 transition">Browse Gigs</Link>
          {user?.role === 'employer' && (
            <Link to="/post-gig" className="text-ink-700 hover:text-brand-600 transition">Post a Gig</Link>
          )}
          {user ? (
            <>
              <Link to="/dashboard" className="text-ink-700 hover:text-brand-600 transition">Dashboard</Link>
              <Link to="/chat" className="text-ink-700 hover:text-brand-600 transition">Messages</Link>
              <button onClick={handleLogout} className="text-ink-700 hover:text-red-600 transition">Logout</button>
              <Link to="/profile" className="font-medium text-ink-900 bg-brand-50 px-3 py-1.5 rounded-full">
                {user.name}
              </Link>
            </>
          ) : (
            <>
              <Link to="/login" className="text-ink-700 hover:text-brand-600 transition">Login</Link>
              <Link
                to="/register"
                className="bg-gradient-to-r from-brand-500 to-brand-700 text-white px-4 py-2 rounded-full shadow-sm hover:shadow-md transition"
              >
                Sign up
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
