import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

const EmployerDashboard = () => {
  const [gigs, setGigs] = useState([]);
  const [applicants, setApplicants] = useState({}); // gigId -> [applications]
  const [openGig, setOpenGig] = useState(null);

  useEffect(() => {
    api.get('/gigs/mine').then((res) => setGigs(res.data));
  }, []);

  const toggleApplicants = async (gigId) => {
    if (openGig === gigId) return setOpenGig(null);
    if (!applicants[gigId]) {
      const { data } = await api.get(`/applications/gig/${gigId}`);
      setApplicants((prev) => ({ ...prev, [gigId]: data }));
    }
    setOpenGig(gigId);
  };

  const decide = async (appId, status, gigId) => {
    await api.put(`/applications/${appId}/status`, { status });
    const { data } = await api.get(`/applications/gig/${gigId}`);
    setApplicants((prev) => ({ ...prev, [gigId]: data }));
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold">Your Posted Gigs</h2>
        <Link to="/post-gig" className="bg-brand-600 text-white px-3 py-1.5 rounded-md text-sm">+ Post Gig</Link>
      </div>
      {gigs.length === 0 && <p className="text-gray-500 text-sm">You haven't posted any gigs yet.</p>}
      <div className="space-y-3">
        {gigs.map((gig) => (
          <div key={gig._id} className="bg-white border border-gray-200 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">{gig.title}</p>
                <p className="text-xs text-gray-400">{gig.status} · {gig.applicantsCount} applicants</p>
              </div>
              <button onClick={() => toggleApplicants(gig._id)} className="text-sm text-brand-600">
                {openGig === gig._id ? 'Hide' : 'View'} Applicants
              </button>
            </div>
            {openGig === gig._id && (
              <div className="mt-4 border-t pt-4 space-y-3">
                {(applicants[gig._id] || []).length === 0 && (
                  <p className="text-sm text-gray-400">No applicants yet.</p>
                )}
                {(applicants[gig._id] || []).map((app) => (
                  <div key={app._id} className="flex justify-between items-start bg-gray-50 rounded-md p-3">
                    <div>
                      <p className="text-sm font-medium">{app.freelancer.name} — ${app.proposedRate}</p>
                      <p className="text-xs text-gray-500 mt-1">{app.coverLetter}</p>
                      <p className="text-xs text-gray-400 mt-1">Skills: {app.freelancer.skills?.join(', ')}</p>
                    </div>
                    <div className="flex gap-2 text-xs">
                      {app.status === 'pending' ? (
                        <>
                          <button onClick={() => decide(app._id, 'accepted', gig._id)}
                            className="bg-green-600 text-white px-2 py-1 rounded">Accept</button>
                          <button onClick={() => decide(app._id, 'rejected', gig._id)}
                            className="bg-red-100 text-red-700 px-2 py-1 rounded">Reject</button>
                        </>
                      ) : (
                        <span className="capitalize text-gray-500">{app.status}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const FreelancerDashboard = () => {
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    api.get('/applications/mine').then((res) => setApplications(res.data));
  }, []);

  return (
    <div>
      <h2 className="text-lg font-semibold mb-6">Your Applications</h2>
      {applications.length === 0 && (
        <p className="text-gray-500 text-sm">
          You haven't applied to anything yet. <Link to="/gigs" className="text-brand-600">Browse gigs</Link>
        </p>
      )}
      <div className="space-y-3">
        {applications.map((app) => (
          <div key={app._id} className="bg-white border border-gray-200 rounded-lg p-4 flex justify-between items-center">
            <div>
              <Link to={`/gigs/${app.gig?._id}`} className="font-medium hover:text-brand-600">
                {app.gig?.title}
              </Link>
              <p className="text-xs text-gray-400 mt-1">Proposed: ${app.proposedRate}</p>
            </div>
            <span className={`text-xs px-2 py-1 rounded-full capitalize ${
              app.status === 'accepted' ? 'bg-green-100 text-green-700' :
              app.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'
            }`}>{app.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const Dashboard = () => {
  const { user } = useAuth();
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {user.role === 'employer' ? <EmployerDashboard /> : <FreelancerDashboard />}
    </div>
  );
};

export default Dashboard;
