// Usage: router.post('/gigs', protect, requireRole('employer'), createGig)
const requireRole = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      res.status(403);
      return next(new Error(`Access denied. Requires role: ${allowedRoles.join(' or ')}`));
    }
    next();
  };
};

module.exports = { requireRole };
