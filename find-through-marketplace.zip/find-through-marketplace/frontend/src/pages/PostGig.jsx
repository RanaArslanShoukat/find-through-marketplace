import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';

const PostGig = () => {
  const [form, setForm] = useState({
    title: '', description: '', skillsRequired: '', budgetType: 'fixed',
    budgetMin: '', budgetMax: '', location: 'Remote',
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const payload = {
        ...form,
        skillsRequired: form.skillsRequired.split(',').map((s) => s.trim()).filter(Boolean),
        budgetMin: Number(form.budgetMin),
        budgetMax: Number(form.budgetMax),
      };
      const { data } = await api.post('/gigs', payload);
      navigate(`/gigs/${data._id}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to post gig');
    }
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-8">
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h1 className="text-xl font-bold mb-6">Post a New Gig</h1>
        {error && <p className="text-red-600 text-sm mb-4">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <input name="title" placeholder="Gig title" required value={form.title} onChange={handleChange}
            className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" />
          <textarea name="description" placeholder="Description" required rows={5} value={form.description}
            onChange={handleChange} className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" />
          <input name="skillsRequired" placeholder="Skills (comma separated)" value={form.skillsRequired}
            onChange={handleChange} className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" />
          <div className="grid grid-cols-3 gap-3">
            <select name="budgetType" value={form.budgetType} onChange={handleChange}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm">
              <option value="fixed">Fixed</option>
              <option value="hourly">Hourly</option>
            </select>
            <input name="budgetMin" type="number" placeholder="Min $" required value={form.budgetMin}
              onChange={handleChange} className="border border-gray-300 rounded-md px-3 py-2 text-sm" />
            <input name="budgetMax" type="number" placeholder="Max $" required value={form.budgetMax}
              onChange={handleChange} className="border border-gray-300 rounded-md px-3 py-2 text-sm" />
          </div>
          <input name="location" placeholder="Location" value={form.location} onChange={handleChange}
            className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" />
          <button className="w-full bg-brand-600 text-white py-2 rounded-md text-sm hover:bg-brand-700">
            Publish Gig
          </button>
        </form>
      </div>
    </div>
  );
};

export default PostGig;
