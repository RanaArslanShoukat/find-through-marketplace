const express = require('express');
const router = express.Router();
const { createGig, getGigs, getGigById, updateGig, deleteGig, getMyGigs } = require('../controllers/gigController');
const { protect } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');

router.get('/', getGigs); // public — anyone can browse gigs
router.get('/mine', protect, requireRole('employer'), getMyGigs);
router.get('/:id', getGigById);
router.post('/', protect, requireRole('employer'), createGig);
router.put('/:id', protect, requireRole('employer'), updateGig);
router.delete('/:id', protect, requireRole('employer'), deleteGig);

module.exports = router;
