const asyncHandler = require('express-async-handler');
const Conversation = require('../models/Conversation');
const Message = require('../models/Message');

// @route POST /api/conversations   { recipientId, gigId? }
// Finds an existing 1:1 conversation or creates one.
const startOrGetConversation = asyncHandler(async (req, res) => {
  const { recipientId, gigId } = req.body;

  let conversation = await Conversation.findOne({
    participants: { $all: [req.user._id, recipientId] },
    ...(gigId ? { gig: gigId } : {}),
  });

  if (!conversation) {
    conversation = await Conversation.create({
      participants: [req.user._id, recipientId],
      gig: gigId || null,
    });
  }

  res.status(201).json(conversation);
});

// @route GET /api/conversations   (all conversations for the logged-in user)
const getMyConversations = asyncHandler(async (req, res) => {
  const conversations = await Conversation.find({ participants: req.user._id })
    .populate('participants', 'name avatarUrl role')
    .populate('gig', 'title')
    .sort('-lastMessageAt');
  res.json(conversations);
});

// @route GET /api/conversations/:id/messages
const getMessages = asyncHandler(async (req, res) => {
  const conversation = await Conversation.findById(req.params.id);
  if (!conversation || !conversation.participants.some((p) => p.toString() === req.user._id.toString())) {
    res.status(403);
    throw new Error('Not authorized to view this conversation');
  }

  const messages = await Message.find({ conversation: req.params.id })
    .populate('sender', 'name avatarUrl')
    .sort('createdAt');
  res.json(messages);
});

// Called from the Socket.io handler as well as optionally over REST as a fallback
const saveMessage = async ({ conversationId, senderId, text }) => {
  const message = await Message.create({ conversation: conversationId, sender: senderId, text, readBy: [senderId] });
  await Conversation.findByIdAndUpdate(conversationId, { lastMessage: text, lastMessageAt: new Date() });
  return Message.findById(message._id).populate('sender', 'name avatarUrl');
};

module.exports = { startOrGetConversation, getMyConversations, getMessages, saveMessage };
