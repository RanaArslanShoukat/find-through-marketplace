# Find Through — Full-Stack Freelance Marketplace (MERN)

A two-sided marketplace: employers post gigs, freelancers browse/apply, both sides chat in real time. Built to demonstrate the core things MERN interviews probe for: JWT auth with refresh-token rotation, role-based access control, relational-style MongoDB schema design, aggregation-pipeline search, Socket.io chat, and file uploads.

## Stack
- **Backend:** Node, Express, MongoDB/Mongoose, Socket.io, JWT, Multer
- **Frontend:** React (Vite), React Router, Tailwind CSS, Axios, Socket.io-client

## Project structure
```
backend/
  models/        Mongoose schemas: User, Gig, Application, Conversation, Message
  controllers/   Business logic per resource
  routes/        Express routers
  middleware/    auth (JWT verify), roleCheck (RBAC), errorHandler
  socket/        Socket.io connection + real-time chat events
  utils/         Token generation helpers
frontend/
  src/context/   AuthContext — holds the in-memory access token + user
  src/api/       Axios instance with automatic 401 → refresh → retry
  src/pages/     Login, Register, GigList, GigDetail, PostGig, Dashboard, Chat, Profile
```

## Getting started

### 1. Backend
```bash
cd backend
cp .env.example .env      # then fill in JWT secrets and your MongoDB URI
npm install
npm run dev                # nodemon, http://localhost:5000
```
You need a running MongoDB instance — either local (`mongod`) or a free MongoDB Atlas cluster (paste the connection string into `MONGO_URI`).

### 2. Frontend
```bash
cd frontend
cp .env.example .env
npm install
npm run dev                # http://localhost:5173
```

The Vite dev server proxies `/api` and `/uploads` to `localhost:5000`, so no CORS headaches locally.

## How the auth flow works (the part interviewers ask about most)
1. On login/register, the server signs a **short-lived access token** (15 min) and a **long-lived refresh token** (7 days).
2. The access token is returned in the JSON body and kept **in memory only** (in `AuthContext`) — never in localStorage, so it isn't exposed to XSS.
3. The refresh token is set as an **httpOnly, sameSite=strict cookie** — inaccessible to JS, sent automatically on requests to `/api/auth/refresh`.
4. An Axios response interceptor watches for `401`s: on the first one, it silently calls `/auth/refresh`, gets a new access token, and retries the original request — the user never sees a login prompt mid-session.
5. Refresh tokens are stored (hashed list) on the User document and rotated on every use, so a stolen refresh token can be invalidated by removing it from that list (`logout` does this).

## Key MongoDB/interview talking points
- **RBAC** — `middleware/roleCheck.js` gates routes like `POST /api/gigs` to `employer` only, and `POST /api/applications` to `freelancer` only.
- **Aggregation pipeline** (`gigController.getGigs`) — `$match` for filters, `$lookup` to join employer info (avoids a second round trip), `$sort`, and `$facet` to get paginated results + total count in one query.
- **Schema relationships** — Gigs reference `employer` (User), Applications reference both `gig` and `freelancer` with a compound unique index (`{gig, freelancer}`) so a freelancer can't double-apply. Messages reference a `Conversation`, which holds a `participants` array — a normalized, referenced design rather than embedding chat history inside User docs.
- **Real-time chat** — Socket.io authenticates each socket connection with the same JWT access token (`socket/socketHandler.js`), joins a room per conversation, and persists every message via the same `messageController` used by the REST fallback route.

## What's stubbed vs. production-ready
- **File uploads** currently save to local disk (`backend/uploads/`) via Multer. Swapping to Cloudinary or S3 is a one-file change — replace the `multer.diskStorage` in `routes/uploadRoutes.js` with `multer-storage-cloudinary` or `multer-s3`; `uploadController.js` doesn't need to change.
- **Payments**: `Gig.paymentStatus` (`unpaid → escrow → released → refunded`) tracks state but isn't wired to a real processor. To add Stripe: create a PaymentIntent when an employer hires a freelancer, move `paymentStatus` to `escrow` on success via webhook, and to `released` when the employer marks the gig complete.
- **Profile updates**: the `Profile` page's save button is UI-only right now (see comment in `Profile.jsx`) — add a `PATCH /api/users/me` route/controller following the same pattern as `gigController.updateGig` to persist it.

## Suggested next steps if you want to extend this for a portfolio
1. Wire up the `PATCH /api/users/me` endpoint.
2. Add Stripe test-mode checkout + webhook handling for the payment states.
3. Add rate limiting (`express-rate-limit`) on `/api/auth/*`.
4. Write a few Jest + Supertest tests for the auth flow and the aggregation search — that combination (JWT + Mongo aggregation tests) is exactly what a lot of MERN take-home assessments ask for.
