import { useEffect, useState } from 'react';
import api from '../api/axios';
import GigCard from '../components/GigCard';

const GigList = () => {
  const [gigs, setGigs] = useState([]);
  const [meta, setMeta] = useState({ page: 1, totalPages: 1, totalResults: 0 });
  const [filters, setFilters] = useState({ keyword: '', skills: '', minBudget: '', maxBudget: '', location: '' });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const fetchGigs = async () => {
    setLoading(true);
    const params = { ...filters, page, limit: 9 };
    Object.keys(params).forEach((k) => !params[k] && delete params[k]);
    const { data } = await api.get('/gigs', { params });
    setGigs(data.gigs);
    setMeta({ page: data.page, totalPages: data.totalPages, totalResults: data.totalResults });
    setLoading(false);
  };

  useEffect(() => { fetchGigs(); }, [page]); // eslint-disable-line

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    fetchGigs();
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Browse Gigs</h1>

      <form onSubmit={handleSearch} className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8 bg-white p-4 rounded-lg border border-gray-200">
        <input placeholder="Keyword" value={filters.keyword}
          onChange={(e) => setFilters({ ...filters, keyword: e.target.value })}
          className="border border-gray-300 rounded-md px-3 py-2 text-sm col-span-2 md:col-span-1" />
        <input placeholder="Skills (react,node)" value={filters.skills}
          onChange={(e) => setFilters({ ...filters, skills: e.target.value })}
          className="border border-gray-300 rounded-md px-3 py-2 text-sm" />
        <input placeholder="Min budget" type="number" value={filters.minBudget}
          onChange={(e) => setFilters({ ...filters, minBudget: e.target.value })}
          className="border border-gray-300 rounded-md px-3 py-2 text-sm" />
        <input placeholder="Max budget" type="number" value={filters.maxBudget}
          onChange={(e) => setFilters({ ...filters, maxBudget: e.target.value })}
          className="border border-gray-300 rounded-md px-3 py-2 text-sm" />
        <button className="bg-brand-600 text-white rounded-md text-sm hover:bg-brand-700">Search</button>
      </form>

      {loading ? (
        <p className="text-gray-500">Loading gigs...</p>
      ) : gigs.length === 0 ? (
        <p className="text-gray-500">No gigs match your filters.</p>
      ) : (
        <>
          <div className="grid md:grid-cols-3 gap-4">
            {gigs.map((gig) => <GigCard key={gig._id} gig={gig} />)}
          </div>
          <div className="flex justify-center items-center gap-4 mt-8 text-sm">
            <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)}
              className="px-3 py-1.5 border rounded-md disabled:opacity-40">Prev</button>
            <span>Page {meta.page} of {meta.totalPages || 1} ({meta.totalResults} results)</span>
            <button disabled={page >= meta.totalPages} onClick={() => setPage((p) => p + 1)}
              className="px-3 py-1.5 border rounded-md disabled:opacity-40">Next</button>
          </div>
        </>
      )}
    </div>
  );
};

export default GigList;
