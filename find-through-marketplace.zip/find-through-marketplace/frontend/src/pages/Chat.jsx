import { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { io } from 'socket.io-client';
import api, { getAccessToken } from '../api/axios';

// The socket connects once per mount and re-authenticates with the current
// in-memory access token (see api/axios.js for where that token lives).
const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000';

const Chat = () => {
  const location = useLocation();
  const [conversations, setConversations] = useState([]);
  const [activeId, setActiveId] = useState(location.state?.conversationId || null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const socketRef = useRef(null);
  const bottomRef = useRef(null);

  useEffect(() => {
    api.get('/conversations').then((res) => setConversations(res.data));
  }, []);

  useEffect(() => {
    socketRef.current = io(SOCKET_URL, { auth: { token: getAccessToken() } });

    socketRef.current.on('newMessage', (msg) => {
      setMessages((prev) => (msg.conversation === activeId ? [...prev, msg] : prev));
    });

    return () => socketRef.current.disconnect();
  }, []); // eslint-disable-line

  useEffect(() => {
    if (!activeId) return;
    api.get(`/conversations/${activeId}/messages`).then((res) => setMessages(res.data));
    socketRef.current?.emit('joinConversation', activeId);
  }, [activeId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = (e) => {
    e.preventDefault();
    if (!text.trim() || !activeId) return;
    socketRef.current.emit('sendMessage', { conversationId: activeId, text });
    setText('');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 grid grid-cols-3 gap-4 h-[70vh]">
      <div className="col-span-1 bg-white border border-gray-200 rounded-lg overflow-y-auto">
        {conversations.map((c) => (
          <button key={c._id} onClick={() => setActiveId(c._id)}
            className={`w-full text-left px-4 py-3 border-b text-sm hover:bg-gray-50 ${activeId === c._id ? 'bg-brand-50' : ''}`}>
            <p className="font-medium">{c.participants.map((p) => p.name).join(', ')}</p>
            <p className="text-xs text-gray-400 truncate">{c.lastMessage || 'No messages yet'}</p>
          </button>
        ))}
        {conversations.length === 0 && <p className="p-4 text-sm text-gray-400">No conversations yet.</p>}
      </div>

      <div className="col-span-2 bg-white border border-gray-200 rounded-lg flex flex-col">
        {activeId ? (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {messages.map((m) => (
                <div key={m._id} className="text-sm">
                  <span className="font-medium text-gray-700">{m.sender?.name}: </span>
                  <span className="text-gray-600">{m.text}</span>
                </div>
              ))}
              <div ref={bottomRef} />
            </div>
            <form onSubmit={sendMessage} className="border-t p-3 flex gap-2">
              <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message..."
                className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm" />
              <button className="bg-brand-600 text-white px-4 rounded-md text-sm">Send</button>
            </form>
          </>
        ) : (
          <p className="m-auto text-gray-400 text-sm">Select a conversation to start chatting</p>
        )}
      </div>
    </div>
  );
};

export default Chat;
