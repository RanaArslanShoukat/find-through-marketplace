const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema(
  {
    gig: { type: mongoose.Schema.Types.ObjectId, ref: 'Gig', required: true, index: true },
    freelancer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    coverLetter: { type: String, required: true },
    proposedRate: { type: Number, required: true },
    resumeUrl: { type: String, default: '' },
    status: { type: String, enum: ['pending', 'accepted', 'rejected', 'withdrawn'], default: 'pending' },
  },
  { timestamps: true }
);

applicationSchema.index({ gig: 1, freelancer: 1 }, { unique: true });

module.exports = mongoose.model('Application', applicationSchema);
