const express = require('express');
const router = express.Router();
const {
  applyToGig,
  getApplicationsForGig,
  getMyApplications,
  updateApplicationStatus,
} = require('../controllers/applicationController');
const { protect } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');

router.post('/', protect, requireRole('freelancer'), applyToGig);
router.get('/mine', protect, requireRole('freelancer'), getMyApplications);
router.get('/gig/:gigId', protect, requireRole('employer'), getApplicationsForGig);
router.put('/:id/status', protect, requireRole('employer'), updateApplicationStatus);

module.exports = router;
